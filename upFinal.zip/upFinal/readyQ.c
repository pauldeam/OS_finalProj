#include "readyQ.h"


//looping through the ready queue

void readyQ(node *r){
	while(readyhead != NULL){
	    checkCPU(r);

	}

}
