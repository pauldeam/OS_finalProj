#ifndef CHECK_CPU /* Include guard */
#define CHECK_CPU

int checkCPU(node *n);
int checkDev(node *n);

#endif 
