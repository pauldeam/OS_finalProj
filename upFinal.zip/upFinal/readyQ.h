#ifndef READY_Q /* Include guard */
#define READY_Q

void readyQ(node *r);

#endif 
